<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Documento senza titolo</title>
<style type="text/css" media="screen">
	@import "style.css";
</style>
</head>
<body>
<?php

	include("PageNavigator.php");
	include("functions.inc.php");
	$PN=new pageNavigator(100,"navigazione","select",3,"navigazione");
	
	$PN->setLanguage("english");
	
	
	echo "SQL LIMIT:".$PN->getLimit()."<br /><br />";
	
	echo $PN->show_page_browsing(false)."<br /><br />";
	echo $PN->show_page_browsing(true,5)."<br /><br />";
	echo $PN->show_RPP_browsing(3,4);
	
?>
</body>
</html>
